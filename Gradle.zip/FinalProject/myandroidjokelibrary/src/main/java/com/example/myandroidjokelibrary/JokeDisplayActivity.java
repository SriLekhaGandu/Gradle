package com.example.myandroidjokelibrary;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;


public class JokeDisplayActivity extends AppCompatActivity {
    TextView jokeTextView;
    String joke;
    ImageView jokeImage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_joke_display);
        jokeTextView=(TextView)findViewById(R.id.joke_display_view);
        joke=getIntent().getExtras().getString("result");
        jokeTextView.setText(joke);
        jokeImage=(ImageView)findViewById(R.id.my_image);
        jokeImage.setImageResource(R.drawable.joker);
    }
}
