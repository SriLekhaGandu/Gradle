package com.example.myjavajokelibrary;

import java.util.List;
import java.util.Random;

import static java.util.Arrays.asList;

public class MyJokeClass {
    List<String> myJokes=asList("Difference between a beautiful night and a horror night.\n" +
            "Beautiful night is,\n" +
            "When you hug your teddy bear and sleep.\n" +
            "Horror night is,\n" +
            "When your teddy bear hugs you BACK.","Those who are single, Let’s sing this song together:\n" +
            "Single bells\n" +
            "Single bells\n" +
            "Single all the way\n" +
            "Oh what fun it is to watch\n" +
            "those couples fight all day. Yay…","Today I saw two blind people fighting,\n" +
            "then I shouted  I am  supporting the one with the knife,\n" +
            "they both ran away.","8 p.m. I get an SMS from my girlfriend: Me or football?!\n" +
            "11 p.m. I SMS my girlfriend: You of course.\n" +
            "\n","A guy in a plane stood up & shouted: HIJACK!\n" +
            "All passengers got scared\n" +
            "From the other end of the plane, a guy shouted back HI JOHN.","Hi guys.\n" +
            "I am so happy and proud of myself and I thought I should share with you!!!\n" +
            "Today I saw myself on TV when I turned it off.");
    public String retriveMyJoke()
    {
        Random random=new Random();
        String myJoke=myJokes.get(random.nextInt(myJokes.size()));
        return myJoke;
    }

}
